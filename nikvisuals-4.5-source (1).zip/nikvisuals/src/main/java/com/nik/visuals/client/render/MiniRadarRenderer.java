package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class MiniRadarRenderer {
    public void render(DrawContext g, float pt) {
        if (!ModConfig.miniRadar) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;

        int size = 56;
        int x = mc.getWindow().getScaledWidth() - size - 12;
        int y = 12;
        float range = 48f;

        GuiDraw.glassPanel(g, x, y, size, size, 8, Style.PANEL, Style.ACCENT_GLOW);
        int cx = x + size / 2, cy = y + size / 2;
        GuiDraw.fillSoftCircle(g, cx, cy, 2, Style.ACCENT);

        float yaw = mc.player.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive()) continue;
            double dx = p.getX() - mc.player.getX();
            double dz = p.getZ() - mc.player.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > range) continue;
            // rotate by -yaw
            double rx = dx * Math.cos(-yaw) - dz * Math.sin(-yaw);
            double rz = dx * Math.sin(-yaw) + dz * Math.cos(-yaw);
            int px = cx + (int) (rx / range * (size / 2 - 4));
            int py = cy + (int) (rz / range * (size / 2 - 4));
            GuiDraw.fillSoftCircle(g, px, py, 2, 0xFFFF5555);
        }
    }
}
