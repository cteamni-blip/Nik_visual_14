package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

@Environment(EnvType.CLIENT)
public class PlayerGlowRenderer {
    public void renderWorld(MatrixStack pose, VertexConsumerProvider buffers, float pt) {
        if (!ModConfig.playerGlow) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null || buffers == null) return;

        try {
            com.mojang.blaze3d.opengl.GlStateManager._disableDepthTest();
        } catch (Throwable ignored) {}

        try {
            Vec3d cam = mc.gameRenderer.getCamera().getCameraPos();
            pose.push();
            Matrix4f m = pose.peek().getPositionMatrix();
            VertexConsumer lines;
            try { lines = buffers.getBuffer(RenderLayers.linesTranslucent()); }
            catch (Throwable t) { lines = buffers.getBuffer(RenderLayers.lines()); }

            for (PlayerEntity p : mc.world.getPlayers()) {
                if (p == mc.player || !p.isAlive()) continue;
                if (p.squaredDistanceTo(mc.player) > 64 * 64) continue;
                Box box = p.getBoundingBox().expand(0.05);
                float a = 0.55f;
                float r = 0.3f, g = 1f, b = 0.5f;
                // has totem?
                boolean totem = ModConfig.enemyTotemIcon && (
                        p.getOffHandStack().getItem().toString().contains("totem")
                                || p.getMainHandStack().getItem().toString().contains("totem"));
                if (totem) { r = 1f; g = 0.85f; b = 0.2f; a = 0.75f; }
                drawBox(lines, m, box.offset(-cam.x, -cam.y, -cam.z), r, g, b, a);
            }
            pose.pop();
        } finally {
            try {
                com.mojang.blaze3d.opengl.GlStateManager._enableDepthTest();
            } catch (Throwable ignored) {}
        }
    }

    private void drawBox(VertexConsumer v, Matrix4f m, Box b, float r, float g, float bl, float a) {
        float x0 = (float) b.minX, y0 = (float) b.minY, z0 = (float) b.minZ;
        float x1 = (float) b.maxX, y1 = (float) b.maxY, z1 = (float) b.maxZ;
        // bottom
        seg(v, m, x0, y0, z0, x1, y0, z0, r, g, bl, a);
        seg(v, m, x1, y0, z0, x1, y0, z1, r, g, bl, a);
        seg(v, m, x1, y0, z1, x0, y0, z1, r, g, bl, a);
        seg(v, m, x0, y0, z1, x0, y0, z0, r, g, bl, a);
        // top
        seg(v, m, x0, y1, z0, x1, y1, z0, r, g, bl, a);
        seg(v, m, x1, y1, z0, x1, y1, z1, r, g, bl, a);
        seg(v, m, x1, y1, z1, x0, y1, z1, r, g, bl, a);
        seg(v, m, x0, y1, z1, x0, y1, z0, r, g, bl, a);
        // pillars
        seg(v, m, x0, y0, z0, x0, y1, z0, r, g, bl, a);
        seg(v, m, x1, y0, z0, x1, y1, z0, r, g, bl, a);
        seg(v, m, x1, y0, z1, x1, y1, z1, r, g, bl, a);
        seg(v, m, x0, y0, z1, x0, y1, z1, r, g, bl, a);
    }

    private void seg(VertexConsumer v, Matrix4f m, float x0, float y0, float z0, float x1, float y1, float z1,
                     float r, float g, float b, float a) {
        float dx = x1 - x0, dy = y1 - y0, dz = z1 - z0;
        float len = MathHelper.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-6f) return;
        float nx = dx / len, ny = dy / len, nz = dz / len;
        v.vertex(m, x0, y0, z0).color(r, g, b, a).normal(nx, ny, nz).lineWidth(2f);
        v.vertex(m, x1, y1, z1).color(r, g, b, a).normal(nx, ny, nz).lineWidth(2f);
    }
}
